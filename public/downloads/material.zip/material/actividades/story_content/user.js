function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6fHBpVR50YI":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

