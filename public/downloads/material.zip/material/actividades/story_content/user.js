function ExecuteScript(strId)
{
  switch (strId)
  {
      case "64nzb5Mqe7I":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

